### What does the merge request do?

...

<!-- Summary of changes and referenced issues, e.g. "closes #<issue-id>" -->

### Implementation notes

<!-- delete if obvious -->

### Summary for release notes

...

<!-- Non-technical summary. Explain this change for interested users, not developers. -->

### Checklist

  - [ ] Add unit tests (if applicable)
  - [ ] Changes to `inkex/` are well documented 
  - [ ] Clean merge request history

