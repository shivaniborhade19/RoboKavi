<!-- Please report new issues at https://inkscape.org/report; this tracker is for staff-confirmed issues only.
     See our full bug reporting guidelines at https://inkscape.org/contribute/report-bugs/ -->

#### Steps to reproduce:
<!-- Describe what you did (step-by-step) so we can reproduce: -->

- open Inkscape
- ...

#### What happened?

...

#### What should have happened?

...

#### Inkscape Version and Operating System:

- Inkscape Version: ... <!-- (run inkscape -V or copy from Help → About Inkscape, top right) -->
- Operating System: ...
- Operating System version: ...

<!-- Example file:
Attach a sample file (or files) highlighting the issue, if appropriate. -->
