.. inkex documentation master file, created by
   sphinx-quickstart on Tue May 18 23:45:21 2021.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to inkex's documentation!
=================================

.. toctree::
   :maxdepth: 4
   :caption: Quickstart

   quickstart
   units

.. toctree::
   :maxdepth: 4
   :caption: Reference

   source/inkex


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
