Files here should only be used in tests and won't be installed with Inkscape extensions.

Folders:

 io - Non SVG files which extensions can read or save to for comparisons.
 svg - SVG files which tests read in and test extensions and modules with.
 cmd - Caches of calls to external programs, used when those programs are not available.
 refs - Comparison files, all the expected outputs of calls.
 batches - Data files where each row contains test data for the module.

