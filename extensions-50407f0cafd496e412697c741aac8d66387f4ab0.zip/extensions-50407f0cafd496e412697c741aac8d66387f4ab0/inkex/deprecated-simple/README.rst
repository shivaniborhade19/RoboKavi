# coding=utf-8This directory contains compatibility layers for all the `simple` modules, such as `simplepath` and `simplestyle`

This directory IS NOT a module path, to denote this we are using a dash in the name and there is no '__init__.py'

